const daysInMonth = 31; // Días en julio
const weekdays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

function generateCalendar() {
    const tbody = document.getElementById('calendar-body');
    tbody.innerHTML = '';

    for (let i = 1; i <= daysInMonth; i++) {
        const tr = document.createElement('tr');
        const date = new Date(2024, 6, i); // Mes de julio (6) en el año 2024
        tr.innerHTML = `
            <td><input type="checkbox" class="select-day" data-day="${i}" onchange="toggleDay(this)"></td>
            ${weekdays.map((day, index) => {
            if (date.getDay() === (index === 6 ? 0 : index + 1)) { // Sunday is 0, Monday is 1, etc.
                return `<td><input type="checkbox" class="select-weekday ${day}" data-day="${i}" onchange="checkWeekday('${day}')"></td>`;
            } else {
                return '<td></td>';
            }
        }).join('')}
        `;
        tbody.appendChild(tr);
    }
}

function toggleAllMonth(checkbox) {
    const isChecked = checkbox.checked;
    document.querySelectorAll('.select-day, .select-weekday').forEach(cb => {
        cb.checked = isChecked;
    });
    weekdays.forEach(day => {
        document.getElementById(`select-${day}`).checked = isChecked;
    });
}

function toggleWeekday(weekday, checkbox) {
    const isChecked = checkbox.checked;
    document.querySelectorAll(`.select-weekday.${weekday}`).forEach(cb => {
        cb.checked = isChecked;
        const dayCheckbox = document.querySelector(`.select-day[data-day="${cb.dataset.day}"]`);
        if (dayCheckbox) {
            dayCheckbox.checked = isChecked;
        }
    });
    checkAllMonth();
}

function toggleDay(dayCheckbox) {
    const day = dayCheckbox.dataset.day;
    const isChecked = dayCheckbox.checked;

    if (!isChecked) {
        document.getElementById('select-all-month').checked = false;
    }

    document.querySelectorAll(`.select-weekday[data-day="${day}"]`).forEach(cb => {
        cb.checked = isChecked;
    });

    weekdays.forEach(weekday => {
        const allChecked = Array.from(document.querySelectorAll(`.select-weekday.${weekday}`)).every(cb => cb.checked);
        document.getElementById(`select-${weekday}`).checked = allChecked;
    });

    checkAllMonth();
}

function checkWeekday(weekday) {
    const allChecked = Array.from(document.querySelectorAll(`.select-weekday.${weekday}`)).every(cb => cb.checked);
    document.getElementById(`select-${weekday}`).checked = allChecked;
}

function checkAllMonth() {
    const allChecked = Array.from(document.querySelectorAll('.select-day')).every(cb => cb.checked);
    document.getElementById('select-all-month').checked = allChecked;
}

generateCalendar();